<?php
/* Template Name: Top Up
*/
if( is_user_logged_in() ) { 
if(isset($_REQUEST['top_up_submit']) && !empty($_REQUEST['top_up'])) {
$top_up = $_REQUEST['top_up'];
$current_credits = get_user_meta(get_current_user_id(),'_credits',true);
$update_credits = $current_credits+$top_up;
update_user_meta(get_current_user_id(),'_credits',$update_credits);
}
get_header(); ?>

			<div id="content">

				<div id="inner-content" class="wrap clearfix">

						<div id="main" class="eightcol first clearfix" role="main">

							<?php if (have_posts()) : while (have_posts()) : the_post(); ?>

							<article id="post-<?php the_ID(); ?>" <?php post_class('clearfix'); ?> role="article" itemscope itemtype="http://schema.org/BlogPosting">

								<header class="article-header">

									<h1 class="page-title" itemprop="headline"><?php the_title(); ?></h1>
									

								</header> <!-- end article header -->

								<section class="entry-content clearfix" itemprop="articleBody">
									<?php the_content(); ?>
									<form name="top_up_credits" id="top_up_credits" method="post" action="">
										<label for="top_up">Number of Credits</label>
										<input type="text" name="top_up" id="top_up" />
										<input type="submit" class="button" value="Submit" name="top_up_submit" />
									</form>
							</section> <!-- end article section -->
							
							
							</article> <!-- end article -->

							<?php endwhile;
							endif; ?>

						</div> <!-- end #main -->

						<?php get_sidebar(); ?>

				</div> <!-- end #inner-content -->

			</div> <!-- end #content -->

<?php get_footer(); 
}
 else {  wp_redirect( home_url() ); exit; }
?>
