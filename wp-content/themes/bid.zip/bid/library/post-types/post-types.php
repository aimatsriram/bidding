<?php
require_once('products-post-type.php');
?>