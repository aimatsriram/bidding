<?php
/*
Template Name: User Bid Status
*/
?>
<?php show_user_bids_status(); ?>
