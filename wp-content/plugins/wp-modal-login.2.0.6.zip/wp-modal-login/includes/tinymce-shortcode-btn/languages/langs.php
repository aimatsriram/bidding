<?php
	$strings = "tinyMCE.addI18n({en:{
		st_shortcode:{
			desc : 'Add Custom Shortcode'
		}
	}});";
?>